package com.oppor14.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

/**
 * Mirino Ottico Custom con:
 * - Griglia Aurea (Phi 1:0.618) / Regola dei Terzi / Off
 * - Livella Elettronica Giroscopica in tempo reale (verde smeraldo quando perfettamente in bolla)
 */
class HudOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class GridMode { GOLDEN_RATIO, RULE_OF_THIRDS, OFF }

    var gridMode: GridMode = GridMode.GOLDEN_RATIO
        set(value) {
            field = value
            invalidate()
        }

    var rollDegrees: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(95, 255, 255, 255)
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // 1. Disegno Griglia Compositiva
        when (gridMode) {
            GridMode.GOLDEN_RATIO -> {
                // Sezione Aurea: 0.382 e 0.618
                val x1 = w * 0.382f
                val x2 = w * 0.618f
                val y1 = h * 0.382f
                val y2 = h * 0.618f
                canvas.drawLine(x1, 0f, x1, h, gridPaint)
                canvas.drawLine(x2, 0f, x2, h, gridPaint)
                canvas.drawLine(0f, y1, w, y1, gridPaint)
                canvas.drawLine(0f, y2, w, y2, gridPaint)
            }
            GridMode.RULE_OF_THIRDS -> {
                val x1 = w / 3f
                val x2 = w * 2f / 3f
                val y1 = h / 3f
                val y2 = h * 2f / 3f
                canvas.drawLine(x1, 0f, x1, h, gridPaint)
                canvas.drawLine(x2, 0f, x2, h, gridPaint)
                canvas.drawLine(0f, y1, w, y1, gridPaint)
                canvas.drawLine(0f, y2, w, y2, gridPaint)
            }
            GridMode.OFF -> {}
        }

        // 2. Livella Elettronica Orizzontale al centro del mirino
        if (gridMode != GridMode.OFF) {
            val cx = w / 2f
            val cy = h / 2f
            val lineHalfWidth = w * 0.16f
            val isLevel = abs(rollDegrees) < 1.0f

            levelPaint.color = if (isLevel) Color.parseColor("#00E676") else Color.parseColor("#80FFD700")
            canvas.save()
            canvas.rotate(-rollDegrees, cx, cy)
            canvas.drawLine(cx - lineHalfWidth, cy, cx + lineHalfWidth, cy, levelPaint)
            canvas.restore()
        }
    }
}
