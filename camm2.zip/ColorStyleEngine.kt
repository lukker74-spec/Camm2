package com.oppor14.procam

import android.graphics.*
import kotlin.math.hypot
import kotlin.random.Random

/**
 * Motore di Color Science & Monochrome Mastering per Oppo Reno 14 5G.
 * Include 8 profili dedicati:
 * - NATURALE (Zero AI)
 * - B&W LEICA M11 MONOCHROM (Bianco e nero ad alto micro-contrasto con filtro giallo/rosso ottico)
 * - B&W KODAK TRI-X 400 (Pellicola bianco e nero analogica con curva a S e grana d'argento fine)
 * - LEICA AUTHENTIC
 * - HASSELBLAD HNCS
 * - iPHONE SMART WARM
 * - PIXEL CONTRAST HDR+
 * - VIVO V70 ZEISS PORTRAIT
 */
enum class PhotoStyleProfile(val displayName: String, val fileTag: String, val isMonochrome: Boolean = false) {
    NATURAL("NATURALE (NO AI)", "NAT"),
    BW_LEICA_MONOCHROM("B&W LEICA MONOCHROM", "BW_MONO", isMonochrome = true),
    BW_KODAK_TRIX("B&W KODAK TRI-X 400", "BW_TRIX", isMonochrome = true),
    LEICA_AUTHENTIC("LEICA AUTHENTIC", "LEICA"),
    HASSELBLAD_HNCS("HASSELBLAD HNCS", "HASSEL"),
    IPHONE_WARM("iPHONE SMART WARM", "IPHONE"),
    PIXEL_HDR("PIXEL CONTRAST HDR+", "PIXEL"),
    VIVO_V70_ZEISS("VIVO V70 ZEISS PORTRAIT", "VIVO70")
}

object ColorStyleEngine {

    /**
     * Fonde 3 fotogrammi ravvicinati (Fase 3: Burst Stacking matematico)
     * per dimezzare il rumore elettronico sul teleobiettivo 3.5x (80mm) e 7x (160mm).
     */
    fun mergeMultiFrameBurst(frames: List<Bitmap>): Bitmap {
        if (frames.isEmpty()) throw IllegalArgumentException("Nessun frame disponibile")
        if (frames.size == 1) return frames.first()

        val base = frames[0].copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(base)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        for (i in 1 until frames.size) {
            paint.alpha = (255f / (i + 1)).toInt()
            canvas.drawBitmap(frames[i], 0f, 0f, paint)
        }
        return base
    }

    /**
     * Applica il profilo colore o il filtro Bianco e Nero d'autore sul Bitmap ad alta risoluzione.
     */
    fun applyStyle(source: Bitmap, style: PhotoStyleProfile): Bitmap {
        if (style == PhotoStyleProfile.NATURAL) return source

        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val matrix = when (style) {
            PhotoStyleProfile.BW_LEICA_MONOCHROM -> buildLeicaMonochromMatrix()
            PhotoStyleProfile.BW_KODAK_TRIX -> buildKodakTriXMatrix()
            PhotoStyleProfile.LEICA_AUTHENTIC -> buildLeicaMatrix()
            PhotoStyleProfile.HASSELBLAD_HNCS -> buildHasselbladMatrix()
            PhotoStyleProfile.IPHONE_WARM -> buildIphoneMatrix()
            PhotoStyleProfile.PIXEL_HDR -> buildPixelMatrix()
            PhotoStyleProfile.VIVO_V70_ZEISS -> buildVivoV70Matrix()
            PhotoStyleProfile.NATURAL -> ColorMatrix()
        }

        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(source, 0f, 0f, paint)

        // Vignettatura ottica naturale per i profili Leica e Pellicola B&W
        if (style == PhotoStyleProfile.LEICA_AUTHENTIC ||
            style == PhotoStyleProfile.BW_LEICA_MONOCHROM ||
            style == PhotoStyleProfile.BW_KODAK_TRIX
        ) {
            applyOpticalVignette(canvas, source.width, source.height)
        }

        // Grana d'argento fine opzionale per il profilo pellicola Kodak Tri-X 400
        if (style == PhotoStyleProfile.BW_KODAK_TRIX) {
            applyAnalogSilverGrain(canvas, source.width, source.height)
        }

        return result
    }

    /**
     * B&W LEICA M11 MONOCHROM:
     * Non è una banale desaturazione, ma simula un vero filtro ottico Arancio/Giallo davanti
     * al sensore monocromatico (42% Rosso, 48% Verde, 10% Blu):
     * - I cieli blu diventano scuri e drammatici
     * - La pelle nei ritratti (specialmente col Tele 3.5x 80mm) risulta luminosa, scolpita e priva di macchie
     * - Neri profondi (-18 offset) e bianchi argentei (1.24x contrasto)
     */
    private fun buildLeicaMonochromMatrix(): ColorMatrix {
        val rWeight = 0.42f
        val gWeight = 0.48f
        val bWeight = 0.10f
        val contrast = 1.24f
        val offset = -18f

        val r = rWeight * contrast
        val g = gWeight * contrast
        val b = bWeight * contrast

        return ColorMatrix(floatArrayOf(
            r, g, b, 0f, offset,
            r, g, b, 0f, offset,
            r, g, b, 0f, offset,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    /**
     * B&W KODAK TRI-X 400:
     * Classico look reportage da camera oscura: contrasto deciso sui mezzitoni (1.30x),
     * neri ricchi e una leggerissima tonalità argento caldo (Warm-Tone Silver).
     */
    private fun buildKodakTriXMatrix(): ColorMatrix {
        val rWeight = 0.35f
        val gWeight = 0.53f
        val bWeight = 0.12f
        val contrast = 1.30f
        val offset = -24f

        val r = rWeight * contrast
        val g = gWeight * contrast
        val b = bWeight * contrast

        return ColorMatrix(floatArrayOf(
            r, g, b, 0f, offset + 2f, // Leggerissimo tono argento caldo
            r, g, b, 0f, offset + 1f,
            r, g, b, 0f, offset,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    private fun buildLeicaMatrix(): ColorMatrix {
        val contrast = 1.16f
        val offset = -14f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, offset,
            0f, contrast * 0.99f, 0f, 0f, offset,
            0f, 0f, contrast * 0.96f, 0f, offset - 3f,
            0f, 0f, 0f, 1f, 0f
        ))
        val saturationMatrix = ColorMatrix().apply { setSaturation(0.90f) }
        contrastMatrix.postConcat(saturationMatrix)
        return contrastMatrix
    }

    private fun buildHasselbladMatrix(): ColorMatrix {
        return ColorMatrix(floatArrayOf(
            1.08f, 0.02f, 0f, 0f, -4f,
            0f, 1.04f, 0.01f, 0f, -4f,
            0f, 0f, 1.02f, 0f, -6f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    private fun buildIphoneMatrix(): ColorMatrix {
        val warmMatrix = ColorMatrix(floatArrayOf(
            1.06f, 0f, 0f, 0f, 6f,
            0f, 1.03f, 0f, 0f, 4f,
            0f, 0f, 0.95f, 0f, -2f,
            0f, 0f, 0f, 1f, 0f
        ))
        val sat = ColorMatrix().apply { setSaturation(1.08f) }
        warmMatrix.postConcat(sat)
        return warmMatrix
    }

    private fun buildPixelMatrix(): ColorMatrix {
        return ColorMatrix(floatArrayOf(
            1.12f, 0f, 0f, 0f, -10f,
            0f, 1.13f, 0f, 0f, -10f,
            0f, 0.02f, 1.18f, 0f, -4f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    private fun buildVivoV70Matrix(): ColorMatrix {
        val zeissMatrix = ColorMatrix(floatArrayOf(
            1.07f, 0.03f, 0f, 0f, 5f,
            0.01f, 1.06f, 0.02f, 0f, 5f,
            0f, 0.01f, 1.05f, 0f, 3f,
            0f, 0f, 0f, 1f, 0f
        ))
        val sat = ColorMatrix().apply { setSaturation(1.12f) }
        zeissMatrix.postConcat(sat)
        return zeissMatrix
    }

    private fun applyOpticalVignette(canvas: Canvas, width: Int, height: Int) {
        val radius = hypot(width / 2f, height / 2f)
        val gradient = RadialGradient(
            width / 2f,
            height / 2f,
            radius,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(125, 0, 0, 0)),
            floatArrayOf(0.0f, 0.56f, 1.0f),
            Shader.TileMode.CLAMP
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun applyAnalogSilverGrain(canvas: Canvas, width: Int, height: Int) {
        // Genera un pattern di micro-grana analogica sottile e lo proietta con tiling veloce
        val tileSize = 128
        val grainTile = Bitmap.createBitmap(tileSize, tileSize, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(tileSize * tileSize)
        val rng = Random(42)
        for (i in pixels.indices) {
            val v = rng.nextInt(0, 255)
            pixels[i] = Color.argb(16, v, v, v)
        }
        grainTile.setPixels(pixels, 0, tileSize, 0, 0, tileSize, tileSize)

        val grainPaint = Paint().apply {
            shader = BitmapShader(grainTile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), grainPaint)
    }
}
