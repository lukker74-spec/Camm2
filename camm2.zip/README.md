# Reno14 ProCam v3.0 Master Edition - Fotocamera Custom per Oppo Reno 14 5G

Progetto completo in Kotlin nativo (CameraX 1.4.0 + Camera2 Interop + VideoCapture 4K OIS+EIS + Custom Monochrome & Color Science Engine) calibrato per **Oppo Reno 14 5G** (MediaTek Dimensity 8350).

## Tutte le novità della Versione 3.0 Master Edition
1. **2 Nuovi Filtri Bianco e Nero d'Autore con Anteprima Live B&W:**
   - **`B&W LEICA MONOCHROM`:** Simula un vero filtro ottico Arancio/Giallo davanti al sensore (42% Rosso, 48% Verde, 10% Blu) con contrasto `1.24x` e vignettatura ottica. Cieli drammatici e incarnati scolpiti sul teleobiettivo 3.5x (80mm).
   - **`B&W KODAK TRI-X 400`:** Emulazione della storica pellicola reportage ISO 400 con curva ad alto contrasto (`1.30x`), punto di nero profondo e micro-grana d'argento analogica generata matematicamente.
   - **Mirino Live B&W:** Quando selezioni uno dei profili Bianco e Nero, anche il mirino in tempo reale diventa monocromatico per farti comporre luci e ombre come su una Leica serie M Monochrom.
2. **Doppia Stabilizzazione Attiva Foto e Video (OIS a 2 assi + EIS):**
   - **OIS Hardware Forzato (`LENS_OPTICAL_STABILIZATION_MODE_ON`):** Sempre attivo sia sul Sony IMX882 (26mm) sia sul Teleobiettivo Periscopico 3.5x (80mm).
   - **EIS Digitale + Preview/Video Stabilization (`CONTROL_VIDEO_STABILIZATION_MODE_ON`):** Attivato sia sull'anteprima live (per inquadrare facilmente a 3.5x e 7x senza tremolii) sia sulla nuova modalità di **Registrazione Video 4K (`REC 4K OIS+EIS`)**.
3. **Integrazione Diretta con la Galleria Nativa Oppo (`com.coloros.gallery3d`):**
   - Foto e video vengono salvati direttamente nella cartella principale **`DCIM/Camera`** di ColorOS con flag `DATE_TAKEN` e scansione immediata `MediaScannerConnection`.
   - Nuovo pulsante **`OPPO ALBUM`** in basso a sinistra che apre istantaneamente l'ultima foto scattata dentro l'app Galleria originale di Oppo.
4. **Mirino Ottico con Griglia Aurea (`PHI GRID`) e Livella Giroscopica:**
   - Sovrapposizione grafica custom (`HudOverlayView.kt`) commutabile tra **Sezione Aurea (1:0.618)**, **Regola dei Terzi (3x3)** e **Off**, con livella elettronica centrale collegata all'accelerometro che diventa verde smeraldo (`#00E676`) quando il telefono è perfettamente in bolla.
